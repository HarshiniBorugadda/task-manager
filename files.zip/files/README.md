# Task Manager

Simple Web Development Task Management System where users can:
- Add new tasks
- List the tasks
- Mark the finished ones
- View pending and/or completed ones

## Technology Stack
- Frontend: Angular
- Backend: Django
- Database: SQLite

## Features
- Add new tasks
- List all tasks
- Mark tasks as completed
- View pending tasks
- View completed tasks

## Setup Instructions

### Angular Frontend
1. Install Angular CLI if not already installed:
   ```bash
   npm install -g @angular/cli
   ```

2. Navigate to the `task-manager` directory and install dependencies:
   ```bash
   cd task-manager
   npm install
   ```

3. Serve the Angular application:
   ```bash
   ng serve
   ```

### Django Backend
1. Create and activate a virtual environment:
   ```bash
   cd backend
   python3 -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run migrations and start the Django server:
   ```bash
   python manage.py migrate
   python manage.py runserver
   ```

## Running the Application in GitHub Codespaces
1. Set up GitHub Codespaces and enable prebuilds.
2. Open Codespaces for the `task-manager` repository.
3. Follow the post-create commands to install necessary dependencies.
4. Open two terminals:
   - In the first terminal, navigate to the `backend` directory and run the Django server.
   - In the second terminal, navigate to the `task-manager` directory and run the Angular application.

## Directory Structure
```
task-manager/
├── backend/
│   ├── backend/
│   │   ├── __init__.py
│   │   ├── asgi.py
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── wsgi.py
│   ├── tasks/
│   │   ├── __init__.py
│   │   ├── admin.py
│   │   ├── apps.py
│   │   ├── models.py
│   │   ├── serializers.py
│   │   ├── tests.py
│   │   ├── urls.py
│   │   └── views.py
│   ├── db.sqlite3
│   ├── manage.py
│   └── requirements.txt
├── src/
│   ├── app/
│   │   ├── add-task/
│   │   │   ├── add-task.component.html
│   │   │   └── add-task.component.ts
│   │   ├── completed-tasks/
│   │   │   ├── completed-tasks.component.html
│   │   │   └── completed-tasks.component.ts
│   │   ├── task-list/
│   │   │   ├── task-list.component.html
│   │   │   └── task-list.component.ts
│   │   └── task.service.ts
│   ├── assets/
│   ├── environments/
│   ├── index.html
│   ├── main.ts
│   └── styles.css
├── .devcontainer/
│   ├── devcontainer.json
│   └── Dockerfile
└── angular.json
```