import { Component } from '@angular/core';
import { TaskService, Task } from '../task.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css'],
})
export class AddTaskComponent {
  taskTitle = '';

  constructor(private taskService: TaskService) {}

  addTask(): void {
    const newTask: Task = { title: this.taskTitle, completed: false };
    this.taskService.addTask(newTask).subscribe(() => {
      this.taskTitle = '';
    });
  }
}